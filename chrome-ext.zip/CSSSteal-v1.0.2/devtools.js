chrome.devtools.panels.elements.createSidebarPane(
	"CSSSteal",
	function(sidebar) {
		sidebar.setPage("index.html");
		sidebar.setHeight("2500px");
	}
);